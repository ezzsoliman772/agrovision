<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CropController;
use App\Http\Controllers\MemberController;


use Kreait\Firebase\Factory;
use App\Http\Controllers\FirebaseController;

Route::get('/users/{user_id}/members', [MemberController::class, 'getMembersByUserId']);
Route::get('/users/{user_id}/crops', [CropController::class, 'getCropsByUserId']);


Route::post('/firebase/store', function (Request $request) {
    $validatedData = $request->validate([
        'key' => 'required|string',
        'value' => 'required|array',
    ]);

    $firebase = (new Factory)
        ->withServiceAccount(config('services.firebase.credentials_file'))
        ->withDatabaseUri('https://agrovision-sensor-data-default-rtdb.firebaseio.com/');

    $database = $firebase->createDatabase();

    $database->getReference($validatedData['key'])->set($validatedData['value']);

    return response()->json([
        'success' => true,
        'message' => 'Data stored successfully in Firebase',
        'data' => $validatedData
    ]);
});
Route::get('/firebase/retrieve', function () {
    try {
        // تهيئة Firebase
        $firebase = (new Factory)
            ->withServiceAccount(config('services.firebase.credentials_file'))
            ->withDatabaseUri('https://agrovision-sensor-data-default-rtdb.firebaseio.com/');

        $database = $firebase->createDatabase();

        // استدعاء البيانات من المسار المحدد
        $data = $database->getReference('sensor_data')->getValue();

        return response()->json([
            'success' => true,
            'message' => 'Data retrieved successfully from Firebase',
            'data' => $data,
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to retrieve data',
            'error' => $e->getMessage(),
        ]);
    }
});

Route::get('/firebase/last-record', function () {
    try {
        $firebase = (new Factory)
            ->withServiceAccount(config('services.firebase.credentials_file'))
            ->withDatabaseUri('https://agrovision-sensor-data-default-rtdb.firebaseio.com/');

        $database = $firebase->createDatabase();

        // جلب آخر إدخال
        $data = $database->getReference('sensor_data')
                         ->orderByKey()
                         ->limitToLast(1)
                         ->getValue();

        // تحويل النتيجة إلى أول عنصر
        $lastRecord = $data ? array_values($data)[0] : null;

        return response()->json([
            'success' => true,
            'message' => 'Last record retrieved successfully',
            'data' => $lastRecord,
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to retrieve last record',
            'error' => $e->getMessage(),
        ]);
    }
});


Route::post('register', [AuthController::class, 'register']);  // Route for registering a user
Route::post('login', [AuthController::class, 'login']);  // Route for logging in

Route::post('/crops', [CropController::class, 'store']);
Route::put('/crops/{id}', [CropController::class, 'update']);
Route::delete('/crops/{id}', [CropController::class, 'destroy']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/add-member', [AdminController::class, 'store']);
    Route::put('/add-member/{id}', [AdminController::class, 'update']);
    Route::delete('/add-member/{id}', [AdminController::class, 'destroy']);
});


Route::middleware('auth:sanctum')->get('user', [AuthController::class, 'user']);
    Route::get('/admin/dashboard', function () {
        return response()->json(['message' => 'Welcome Admin!']);
    });

// Routes for User
Route::middleware(['auth:sanctum', 'role:user'])->group(function () {
    Route::get('/user/dashboard', function () {
        return response()->json(['message' => 'Welcome User!']);
    });
});
