<?php

namespace App\Http\Controllers;
use App\Models\Crop;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CropController extends Controller
{
    public function store(Request $request)
{
    // تحقق من صحة البيانات
    $validatedData = $request->validate([
        'user_id' => 'required|exists:users,id', // تأكد من إرسال user_id
        'productName' => 'required|string|max:255',
        'productCategory' => 'required|string|max:255',
        'pricePerKilo' => 'required|numeric',
        'quantity' => 'required|integer',
        'status' => 'required|string',
        'photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ]);

    // Get the currently authenticated user using Sanctum
    $user = auth('sanctum')->user();

    // If no user is authenticated, return an Unauthorized response
    if (!$user) {
        return response()->json(['message' => 'Unauthorized'], 401);
    }

    // تحميل الصورة إذا تم إرسالها
    $photoPath = null;
    if ($request->hasFile('photo')) {
        $photoPath = $request->file('photo')->store('/photos', 'public');
    }

    // إنشاء السجل في قاعدة البيانات
    $crop = Crop::create($validatedData);
    return response()->json(['message' => 'Crop added successfully', 'data' => $crop]);
}
public function update(Request $request, $id)
{
    $crop = Crop::find($id);

    if (!$crop) {
        return response()->json(['error' => 'Crop not found'], 404);
    }

    // التحقق من البيانات
    $request->validate([
        'user_id' => 'required|integer',
        'productName' => 'required|string|max:255',
        'productCategory' => 'required|string|max:255',
        'pricePerKilo' => 'required|numeric',
        'quantity' => 'required|integer',
        'status' => 'required|string',
        'photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ]);

    // تحديث البيانات بما فيها user_id
    $crop->update($request->only([
        'user_id', 'productName', 'productCategory', 'pricePerKilo', 'quantity', 'status'
    ]));

    return response()->json([
        'message' => 'Product updated successfully',
        'crop' => $crop
    ]);
}

public function destroy($id)
{
    try {
        // Find the crop
        $crop = Crop::findOrFail($id);

        // Delete the crop
        $crop->delete();

        return response()->json(['message' => 'Crop deleted successfully'], 200);
    } catch (\Exception $e) {
        // Log the error and return a 500 response
        \Log::error($e->getMessage());

        return response()->json(['error' => 'An error occurred while deleting the crop'], 500);
    }
}

public function getCropsByUserId($user_id)
    {
        try {
            // الحصول على الأعضاء المرتبطين بـ admin_id
            $crop = Crop::where('user_id', $user_id)->get();

            // التحقق إذا كانت النتيجة فارغة
            if ($crop->isEmpty()) {
                return response()->json(['message' => 'No Crop found for this admin.'], 404);
            }

            // إعادة الأعضاء في شكل JSON
            return response()->json(['Crops' => $crop], 200);
        } catch (\Exception $e) {
            // التعامل مع الأخطاء
            return response()->json(['error' => 'Something went wrong!', 'details' => $e->getMessage()], 500);
        }
    }

}
