<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use App\Models\SensorData;

class FetchSensorData extends Command
{
    protected $signature = 'fetch:sensordata';
    protected $description = 'Fetch sensor data from Firebase and store it in the database';

    public function handle()
    {
        putenv('GOOGLE_APPLICATION_CREDENTIALS=' . base_path('storage/firebase/service_account.json'));

        $firebase_url = 'https://agrovision-sensor-data-default-rtdb.firebaseio.com/sensor_data.json';

        $response = Http::get($firebase_url);

        if ($response->successful()) {
            $sensorDataArray = $response->json();

            if (!empty($sensorDataArray)) {
                foreach ($sensorDataArray as $sensorId => $data) {
                    SensorData::create([
                        'sensor_id' => $sensorId,
                        'ec' => $data['EC'] ?? null,
                        'fertility' => $data['Fertility'] ?? null,
                        'humidity' => $data['Hum'] ?? null,
                        'k' => $data['K'] ?? null,
                        'n' => $data['N'] ?? null,
                        'p' => $data['P'] ?? null,
                        'ph_level' => $data['PH'] ?? null,
                        'temperature' => $data['Temp'] ?? null,
                        'recorded_at' => now(),
                    ]);
                }

                $this->info('✅ Sensor data fetched and stored successfully.');
            } else {
                $this->warn('⚠️ No sensor data found.');
            }
        } else {
            $this->error('❌ Failed to fetch data from Firebase. Response: ' . $response->body());
        }
    }
}
